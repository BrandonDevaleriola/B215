export const logged = (value, {kind, name}) => {
	if (kind === "class") {
		return class extends value {
			constructor(...args) {
				super(...args);
				console.log(`Constructing ${name}, with arguments ${args.join(", ")}`);
			}
		}
	}
}