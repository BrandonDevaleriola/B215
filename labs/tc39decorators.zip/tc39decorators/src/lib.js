import { logged } from './log.decorator'

@logged
class Person {
	constructor(name, age) {
		this.name = name;
		this.age = age;
	}
}

const user = new Person('Brandon', 34);
console.log(user);